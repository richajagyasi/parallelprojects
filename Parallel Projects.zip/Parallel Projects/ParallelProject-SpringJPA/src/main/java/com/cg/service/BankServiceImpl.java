package com.cg.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.dao.BankDaoImpl;
import com.cg.entities.Bank;
import com.cg.entities.Transaction;

@Service("bankService")
public class BankServiceImpl implements BankService {

	@Autowired
	private BankDaoImpl bankDao;

	public void addAccount(Bank bankPojo) {
		bankDao.addUserAccount(bankPojo);
	}

	public Bank checkBalance(int accountNo) {
		return bankDao.getBalance(accountNo);
	}

	public Bank depositMoney(int accountNumber, long amount, Transaction trans) {
		return bankDao.depositMoney(accountNumber, amount, trans);
	}

	public Bank withdrawMoney(int accountNumber, long amount, Transaction tran) {

		return bankDao.withdrawMoney(accountNumber, amount, tran);
	}

	public Bank transferMoney(int accountNumber01, long amount01, int accountNumber02, Transaction tran1,
			Transaction tran2) {
		return bankDao.transferMoney(accountNumber01, amount01, accountNumber02, tran1, tran2);
	}

	public String getTransactionDetails(int accountNumber) {
		List<Transaction> hm = bankDao.getTransaction(accountNumber);
		Iterator<Transaction> i = hm.iterator();
		String transactions = "";
		while (i.hasNext()) {
			Transaction trans = (Transaction) i.next();
			transactions = transactions + ""+ trans.getTranid() +"\t\t\t"+ trans.getAcNo() + "\t\t\t" + trans.getType();
		}
		return transactions;
	}

}
