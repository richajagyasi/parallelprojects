package com.cg.ui;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.Exception.InvalidDataValidation;
import com.cg.entities.Bank;
import com.cg.entities.Transaction;
import com.cg.service.BankServiceImpl;
import com.cg.validation.Validator;

public class BankUi {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Bank bank;
		Transaction transaction;
		@SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		BankServiceImpl bankService = context.getBean("bankService", BankServiceImpl.class);
		int choice;
		char option;
		    do {
			System.out.println("****Welcome to XYZ Bank****");
			System.out.println("1. Create Account");
			System.out.println("2. Check Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transaction");
			System.out.println("7. Exit");
			System.out.println("Enter yout choice:");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter your name:");
				String name = scanner.next();
				try {
					while (!Validator.checkName(name)) {
						System.out.print("Invalid Name Format.\nEnter your name again: ");
						name = scanner.next();
					}
				} catch (InvalidDataValidation e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Enter your phone number ( MUST CONTAIN ONLY TEN DIGITS )");
				String phno = scanner.next();
				try {
					while (!Validator.checkPhoneNumber(phno)) {
						System.out.print("Enter your phone number again: ");
						phno = scanner.next();
					}
				} catch (InvalidDataValidation e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				System.out.println("Enter initial balance:");
				long amt = scanner.nextLong();
				int acno = (int) ((Math.random()) * 100000000);
				bank = new Bank(acno, name, phno, amt);
				bankService.addAccount(bank);
				System.out.println("Account Created Successfully. " + name + " Your account number is " + acno);
				break;

			case 2:
				System.out.println("Enter your Account number: ");
				int accountNumber = scanner.nextInt();
//				while(!BankUserDataValidation.checkAccNo(accountNumber))					//validating account number
//            	{
//                	 System.out.print("Enter your account number : ");
//                	 accountNumber=scanner.nextInt();
//            	}
				bank = bankService.checkBalance(accountNumber);
				System.out
						.println("Your Account balance is " + bank.getBalance());
				break;

			case 3:
				System.out.println("Enter your Account number: ");
				int accountNumber1 = scanner.nextInt();

				System.out.println("Enter the amount you want to deposit: ");
				long amount = scanner.nextLong();
				int tid = (int) ((Math.random()) * 100000);
				transaction = new Transaction(tid, accountNumber1, "" + LocalDate.now() + ""
						+ LocalTime.now() + " Rs." + amount + " Deposited Successfully \n");
				bank = bankService.depositMoney(accountNumber1, amount, transaction);
				System.out.println(amount + " Deposited successfully");
				break;

			case 4:
				System.out.println("Enter your Account number: ");
				int accountNumberr = scanner.nextInt();

				System.out.println("Enter the amount you want to withdraw: ");
				long amountt = scanner.nextLong();
				int tidd = (int) ((Math.random()) * 100000);
				transaction = new Transaction(tidd, accountNumberr, "" + LocalDate.now() + ""
						+ LocalTime.now() + " Rs." + amountt + " Withdrawn Successfully \n");
				bank = bankService.withdrawMoney(accountNumberr, amountt, transaction);
				System.out.println(amountt + " withdrawn successfully");
				break;

			case 5:
				System.out.println("Enter your Account number: ");
				int accountNumber01 = scanner.nextInt();

				System.out.println("Enter Account number to which you want to transfer: ");
				int accountNumber02 = scanner.nextInt();
				
				System.out.println("Enter the amount you want to transfer: ");
				long amount01 = scanner.nextLong();
				
				int ttid1 = (int) ((Math.random()) * 100000);
				int ttid2 = (int) ((Math.random()) * 100000);
				Transaction tran1 = new Transaction(ttid1, accountNumber01, "" + LocalDate.now()
						+ "" + LocalTime.now() + " Rs." + amount01 + "Sent Successfuly");
				Transaction tran2 = new Transaction(ttid2, accountNumber02, "" + LocalDate.now()
						+ "" + LocalTime.now() + " Rs." + amount01 + "Received Successfuly");
				bank = bankService.transferMoney(accountNumber01, amount01, accountNumber02, tran1, tran2);
				System.out.println(amount01 + " Sent successfully");
				break;

			case 6:
				System.out.println("Enter your account number: ");
				int accountNumber111 = scanner.nextInt();
				// validating account number

				System.out.println("Your Transaction Deatils ");
				System.out.println("\nTransaction Id: \t Account Number: \t Date & Time \t\t\t\t Amount \t\t Transaction Type:");
				System.out.println(bankService.getTransactionDetails(accountNumber111));
				break;

			case 7:
				System.out.println("Thank You for Banking with Us!!");
				System.exit(0);
				break;

			default:
				System.out.println("Enter the choices between 1-7");
			}
			System.out.print("Do you want to continue (y/n)...? : ");
			option = scanner.next().charAt(0);
			if(option == 'y' || option=='Y')
				continue;
			else {
				System.out.println("Thank You for Banking with Us!");
				System.exit(0);
			}
		} while(choice!=7);
	      scanner.close();
	}

}
