package com.cg.service;

import com.cg.entities.Bank;
import com.cg.entities.Transaction;

public interface BankService {
	public void addAccount(Bank bankPojo);
	
	public Bank checkBalance(int accountNo);
	
	public Bank depositMoney(int accountNumber,long amount,Transaction tran);
	
	public Bank withdrawMoney(int accountNumber, long amount,Transaction trans);
	
	public String getTransactionDetails(int accountNumber);

	public Bank transferMoney(int accountNumber01, long amount01, int accountNumber02,Transaction trans1,Transaction trans2); 
}
