package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entities.Bank;
import com.cg.entities.Transaction;

@Repository("bankDAO")
@Transactional
public class BankDaoImpl implements BankDao {

	@PersistenceContext
	private EntityManager entityManager;

	Bank bank;

	Transaction transactionPojo;

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	public void addUserAccount(Bank bank) {
		entityManager.persist(bank);
	}

	public Bank getBalance(int accountNo) {
		// TODO Auto-generated method stub
		bank = entityManager.find(Bank.class, accountNo);
		return bank;
	}

	public Bank depositMoney(int accountNumber, long amount, Transaction tran) {
		bank = entityManager.find(Bank.class, accountNumber);
		bank.setBalance(bank.getBalance() + amount);
		entityManager.persist(bank);
		entityManager.persist(tran);
		return bank;
	}

	public Bank withdrawMoney(int accountNumber, long amount, Transaction tran) {
		bank = entityManager.find(Bank.class, accountNumber);
		bank.setBalance(bank.getBalance() - amount);
		entityManager.persist(bank);
		entityManager.persist(tran);
		return bank;
	}

	public List<Transaction> getTransaction(int accountNumber) {
		@SuppressWarnings("unchecked")
		TypedQuery<Transaction> query = (TypedQuery<Transaction>) entityManager
				.createQuery("SELECT t FROM Transaction t where acNo = ?1").setParameter(1, accountNumber);
		List<Transaction> transaction = query.getResultList();
		return transaction;
	}

	public Bank transferMoney(int accountNumber01, long amount01, int accountNumber02, Transaction tran1,
			Transaction tran2) {

		Bank bank1 = entityManager.find(Bank.class, accountNumber01);
		bank1.setBalance(bank.getBalance() - amount01);
		entityManager.persist(bank1);
		entityManager.persist(tran1);
		Bank bank2 = entityManager.find(Bank.class, accountNumber02);
		bank2.setBalance(bank.getBalance() + amount01);
		entityManager.persist(bank2);
		entityManager.persist(tran2);
		return bank;
	}
	/*
	 * checking account
	 */

	
		public boolean checkAccNo(int accountNumber) {
			
			Bank bank=entityManager.find(Bank.class, accountNumber);
			System.out.println(bank);
			if(bank!=null)
				return false;
			else {

				System.out.println("123");
				return true;
		}}

}
