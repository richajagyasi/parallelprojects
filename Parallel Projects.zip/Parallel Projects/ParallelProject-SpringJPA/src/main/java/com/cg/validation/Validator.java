package com.cg.validation;

import java.util.regex.Pattern;

import com.cg.Exception.InvalidDataValidation;
import com.cg.dao.BankDaoImpl;

public class Validator {

	static BankDaoImpl bankDAO;
	
	public static boolean checkName(String name) throws InvalidDataValidation{
		
		if (Pattern.matches("([A-Z])([a-z])*",name))
		   return true;
	   else
		   return false;
	}
	
	
	public static boolean checkPhoneNumber(String number) throws InvalidDataValidation
	{
		try {
			if (number.matches("[0-9]+") && number.length() == 10) {
				return true;
			} else {
				throw new InvalidDataValidation("Invalid Phone number.");
			}
		} catch (InvalidDataValidation e) {
			return false;
		}
	}
	
	public static boolean checkAccNo(int accountNumber)
	{
		if(bankDAO.checkAccNo(accountNumber))
			return true;
			else
			{
				System.out.println("INVALID ACCOUNT NUMBER");
			return false;
			}
     }
	
}
