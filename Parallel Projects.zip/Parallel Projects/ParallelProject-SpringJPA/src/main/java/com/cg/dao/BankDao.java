package com.cg.dao;

import java.util.List;

import com.cg.entities.Bank;
import com.cg.entities.Transaction;

public interface BankDao {
	public void addUserAccount(Bank bank);
	
	public Bank getBalance(int accountNo);
	
	public Bank depositMoney(int accountNumber,long amount,Transaction tran);
	
	public Bank withdrawMoney(int accountNumber, long amount,Transaction tran);
	
	public List<Transaction> getTransaction(int accountNumber);

	public Bank transferMoney(int accountNumber01, long amount01, int accountNumber02,Transaction tran1,Transaction tran2);
}
