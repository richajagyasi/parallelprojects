package com.cg.Exception;

public class InvalidDataValidation extends Exception {

	String s1;

	public InvalidDataValidation(String s) {
		s1 = s;

	}

	public String toString() {
		return (s1);
	}

	
}
