package com.cg.ImportedOrder.Service;

import java.util.List;

import com.cg.ImportedOrder.Bean.Order;

public interface OrderService {

	public List<Order> createOrder(Order order);
	public List<Order> updateOrder(int id,Order order);
	public List<Order> viewAllOrders() ;
	public List<Order> viewOrderByRange(int low,int high) ;
	public List<Order> viewOrderByAmount(double amount);
	
}
