package com.cg.ImportedOrder.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ImportedOrder.Bean.Order;
import com.cg.ImportedOrder.Service.OrderService;

@RestController
public class OrderController {

	@Autowired
	OrderService orderService;
	
	@RequestMapping(value="/addorder", method=RequestMethod.POST)
	public List<Order> createOrder(@RequestBody Order order)                        //controller method for adding
	{
		return orderService.createOrder(order);
	}
	
	@PutMapping("/update/{id}")
	public List<Order> updateOrder(@PathVariable int id,@RequestBody Order order)   //controller method for updating
	{
		return orderService.updateOrder(id, order);
	}
	
	@RequestMapping("/orders")                                       
	public List<Order> viewAllOrders()                                               // controller method for viewing all orders
	{
		return orderService.viewAllOrders();
	}
	
	@RequestMapping("/range/{low}/{high}")
	public List<Order> viewOrderByRange(@PathVariable int low, @PathVariable int high)   //controller method for viewing orders within a quantity range
	{
		return orderService.viewOrderByRange(low, high);
	}
	
	@RequestMapping("/greater/{amount}")
	public List<Order> viewOrderByAmount(@PathVariable double amount)                      //controller method for viewing orders greater than a given amount
	{
		return orderService.viewOrderByAmount(amount);
	}
	
}








