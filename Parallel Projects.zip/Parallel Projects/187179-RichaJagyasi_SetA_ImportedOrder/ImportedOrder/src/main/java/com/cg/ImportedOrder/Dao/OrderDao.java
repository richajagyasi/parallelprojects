package com.cg.ImportedOrder.Dao;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.cg.ImportedOrder.Bean.Order;

@Repository
public interface OrderDao extends JpaRepository<Order,Integer> {

	@Query("from Order where id=:c")
	Optional<Order> findById(@Param("c") int id);
	
	 @Query("from Order where quantity BETWEEN :l AND :h")
	 List<Order> findByQuantity(@Param("l")int low,@Param("h") int high);
	 
	 @Query("from Order where amount>:a")
	 List<Order> findByAmount(@Param("a") double amount);
	
}
