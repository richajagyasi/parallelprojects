package com.cg.ImportedOrder.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ImportedOrder.Bean.Order;
import com.cg.ImportedOrder.Dao.OrderDao;


@Service
public class OrderServiceImpl implements OrderService {
	
	@Autowired
	OrderDao orderDao;

	@Override
	public List<Order> createOrder(Order order)                          //service method for adding
	{
		order.setAmount(order.getPrice()*75*order.getQuantity());
		order.setCharges((1.25/100)*order.getAmount());
		orderDao.save(order);
		return orderDao.findAll();
	}

	@Override
	public List<Order> updateOrder(int id, Order order)                   //service method for updating
	{
		Optional<Order> optional=orderDao.findById(id);
		if(optional.isPresent())
		{
			Order order1=optional.get();
			order1.setPrice(order.getPrice());
			order1.setQuantity(order.getQuantity());
			double amount=order.getPrice()*75*order.getQuantity();
			double charges = amount* 0.0125;
			order1.setAmount(amount);
			order1.setCharges(charges);
			orderDao.save(order1);
		}
		return viewAllOrders();
	}

	@Override
	public List<Order> viewAllOrders()                               //service method for viewing all orders
	{
		return orderDao.findAll();
	}

	@Override
	public List<Order> viewOrderByRange(int low, int high)          //service method for viewing orders within a quantity range
	{
		return orderDao.findByQuantity(low,high);
	}

	@Override
	public List<Order> viewOrderByAmount(double amount)              //service method for viewing orders greater than a given amount
	{
		return orderDao.findByAmount(amount);
	}

}
