package pp.dao;
import java.util.HashMap;
import pp.bean.Customer;
public class BankDao {
	Customer beankBeanObj;
		
		HashMap<Long, Customer> hm = new HashMap<Long, Customer>();
		
		public void addCustomer(Customer beankBeanObj) {			// METHOD TO ADD A CUSTOMER 
			this.beankBeanObj = beankBeanObj;						// BY SAVING THE BANK BEAN OBJECT
			hm.put(beankBeanObj.getAccNo(), beankBeanObj);			// IN HASH MAP
		}
		
		public HashMap<Long, Customer> hm(){						// METHOD TO RETURN HASH MAP OBJECT
			return hm;
		}
	}

