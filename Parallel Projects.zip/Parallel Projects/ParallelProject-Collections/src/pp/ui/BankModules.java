package pp.ui;
import pp.bean.Customer;
import pp.service.BankService;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Pattern;

public class BankModules {
	    BankService bankServiceObj = new BankService();
		Scanner sc = new Scanner(System.in);
		
		//BANK MODULES METHODS
		
		public void createAccount() {
			System.out.print("Enter Name: ");
			String name = nameCheck(sc.next());
			System.out.print("Enter Mobile No.: ");
			long mobNo = mobCheck(sc.nextLong());
			long accNo = mobNo - 1234;
			System.out.print("Enter Balance: "); 
			float balance = amountCheck(sc.nextFloat());
			Customer bankBeanObjCreateAccountObj = new Customer(accNo, name, mobNo, balance);
			System.out.println("Account created with Account Number: " +accNo);
			bankServiceObj.bankAccountCreate(bankBeanObjCreateAccountObj);
		}
		
		public void showBalance() {
			System.out.print("Enter Account Number: ");
			long accNo = sc.nextLong();
			Customer bankBeanShowBalObj = new Customer(accNo);
			bankServiceObj.showBalanceSer(bankBeanShowBalObj);
		}
		
		public void deposit() {
			System.out.print("Enter Account Number: ");
			long accNo = sc.nextLong();
			System.out.print("Enter Deposit Amount: ");
			float depAmount = amountCheck(sc.nextFloat());
			Customer bankBeanDeptObj = new Customer(accNo, depAmount);
			bankServiceObj.depositSer(bankBeanDeptObj);
		}
		
		public void withdraw() {
			System.out.print("Enter Account Number: ");
			long accNo = sc.nextLong();
			System.out.print("Enter Withdraw Amount: ");
			float withdrawAmount = amountCheck(sc.nextFloat());
			Customer bankBeanWithdrawObj = new Customer(withdrawAmount, accNo);
			bankServiceObj.withdrawSer(bankBeanWithdrawObj);
		}
		
		public void fundTransfer() {
			System.out.println("Enter Source Account Number: ");
			long sourceAccNo = sc.nextLong();
			System.out.println("Enter Destination Account Number: ");
			long destAccNo = sc.nextLong();
			System.out.println("Enter Amount to transfer: ");
			float transferAmount = amountCheck(sc.nextFloat());
			Customer bankBeanFundTransObj = new Customer(sourceAccNo, destAccNo, transferAmount);
			bankServiceObj.transferSer(bankBeanFundTransObj);
			String transactions = transferAmount+ " transferred from Account number " +sourceAccNo+ " to " +destAccNo;
			bankBeanFundTransObj = new Customer(transactions);
		}
		
		public void printTransactions() {
			System.out.println(Arrays.toString(Customer.transactions));
		}
		
		//CHECKER METHODS
		
		// METHOD TO CHECK IF THE AMOUNT IS LESS THAN 0
		public float amountCheck(float amount) {
			while(true) {
				if(amount<=0) {
					System.out.println("Amount should be greater than 0.");
					System.out.println("Enter again: ");
					amount = sc.nextInt();
				}
				else {
					return amount;
				}
			}
		}
		
		// METHOD TO VALIDATE NAME
		public String nameCheck(String name) {
			while(true) {
				if(Pattern.matches("([A-Z])*([a-z])*", name)){
					return name;
				}
				else {
					System.out.println("Name should only have alphabets.");
					System.out.println("Enter again: ");
					name = sc.next();
				}
			}
		}
		
		//	METHOD TO CHECK LENGTH OF MOBILE NUMBER
		public long mobCheck(long mob) { 
			while(true) {
				if(String.valueOf(mob).length() < 10) {
					System.out.println("Enter valid mobile number.");
					mob = sc.nextLong();
				}
				else {
					return mob;
				}
			}
		}
	}
