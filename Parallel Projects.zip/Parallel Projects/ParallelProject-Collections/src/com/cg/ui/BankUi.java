package com.cg.ui;

import java.util.Scanner;

import com.cg.exception.*;
import com.cg.service.BankServiceImpl;
import com.cg.service.BankService;

public class BankUi {

	public static void main(String[] args) throws AccountNotFoundException {

		Scanner scanner = new Scanner(System.in);
		BankServiceImpl bankservice = new BankServiceImpl();
		
		long accountNo, toAccountNo;
		int amount,pin,balance,choice;
		char option;
		boolean result;
		
		// To ask choice from users and perform operations
		    do {
			
			System.out.println("****Welcome to XYZ Bank !!****");
			System.out.println("1. Create Account");
			System.out.println("2. Check Balance");
			System.out.println("3. Deposit");
			System.out.println("4. Withdraw");
			System.out.println("5. Fund Transfer");
			System.out.println("6. Print Transcations");
			System.out.println("7. Exit");

			System.out.println("Enter your Choice");
			choice = scanner.nextInt();
			
			switch (choice) {

			// to create account

			case 1:

				System.out.println("Enter your name");
				String name = scanner.next();
				
				String regexUserName = "[A-Za-z\\s]+$";
				while (!name.matches(regexUserName)) {
					System.out.println("Invalid name. Enter again:");
					name = scanner.next();
				}

				System.out.println("Enter your phone number");
				String phone = scanner.next();
				String phone_format = ("[7-9][0-9]{9}");

				while (!phone.matches(phone_format)) {
					while (phone.length() < 10 || phone.length() > 10) {

						System.out.println("Phone number should be 0f 10 digits");
						System.out.println("Enter again:");
						phone = scanner.next();
					}
					System.out.println("Invalid number.");
					System.out.println("Enter again:");
					phone = scanner.next();
				}

				accountNo = Long.parseLong(phone) - 10000;

				System.out.println("Set a Pin");
				pin = scanner.nextInt();

				while (String.valueOf(pin).length() < 4 || String.valueOf(pin).length() > 4) {

					System.out.println("Pin should be 0f 4 digits");
					System.out.println("Enter again:");
					pin = scanner.nextInt();
				}

				System.out.println("Enter initial Balance");
				balance = scanner.nextInt();

				while (balance < 1000) {
					System.out.println("Minimum Balance should be 1000");
					System.out.println("Enter again:");
					balance = scanner.nextInt();

				}
				try {
					
				bankservice.createAccount(name, accountNo, phone, pin, balance);
				System.out.println("Account Created Successfully !!!");
				System.out.println("Your Account number is "+accountNo);
				} catch (AccountAlreadyExistsException e) {

					System.out.println(e);
					break;
				}
				break;

			// to show balance
			case 2:

				System.out.println("Enter your account number:");
				accountNo = scanner.nextLong();

				try {
					balance = bankservice.showBalance(accountNo);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Balance :" + balance);

				break;

			// to deposit

			case 3:

				System.out.println("Enter your account no:");
				accountNo = scanner.nextLong();

				System.out.println("Enter amount you want to deposit:");
				amount = scanner.nextInt();

				try {
					balance = bankservice.deposit(accountNo, amount);
					balance = bankservice.showBalance(accountNo);
				}

				catch (AccountNotFoundException e) {

					System.out.println(e);
					break;
				}

				System.out.println("You deposited "+amount);
				System.out.println("Your current balance is "+balance);

				break;

			// to withdraw

			case 4:

				System.out.println("Enter your account no");
				accountNo = scanner.nextLong();

				System.out.println("Enter amount you want to withdraw");
				amount = scanner.nextInt();

				try {
					balance = bankservice.withdraw(accountNo, amount);
					result = bankservice.validateBalance(accountNo, amount);
					balance = bankservice.showBalance(accountNo);

				} catch (AccountNotFoundException e) {

					System.out.println(e);
					break;

				} catch (LowBalanceException e) {

					System.out.println(e);
					break;
				}

				System.out.println("You Withdrew " + amount);
				System.out.println("Your current balance is " + balance);

				break;

			// to transfer fund

			case 5:

				int senders_balance = 0;
				int recievers_balance = 0;

				System.out.println("Enter your account no");
				accountNo = scanner.nextLong();

				System.out.println("Enter account number to which you want to transfer money");
				toAccountNo = scanner.nextLong();

				System.out.println("Enter amount to transfer");
				amount = scanner.nextInt();

				try {
					result = bankservice.validateBalance(accountNo, amount);
					result = bankservice.transferfund(accountNo, toAccountNo, amount);

					senders_balance = bankservice.showBalance(accountNo);
					recievers_balance = bankservice.showBalance(toAccountNo);

				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				} catch (LowBalanceException e) {
					System.out.println(e);
					break;
				}

				System.out.println("Rs "+amount+" transferred Successfully");
				break;

			// to show transactions
			case 6:

				String s = null;
				System.out.println("Enter account number");
				accountNo = scanner.nextLong();
				System.out.println("Enter pin");
				pin = scanner.nextInt();
				try {
					s = bankservice.setTrans(accountNo);
					System.out.println(s);
				} catch (AccountNotFoundException e) {
					System.out.println(e);
					break;
				}

				// to exit
			case 7:
				System.out.println("Thank You for Banking with Us!");
				System.exit(0);
				break;
			default:
				System.out.println("Please Enter choice between 1 - 7 ");
			}
			System.out.print("Do you want to continue (y/n)...? : ");
			option = scanner.next().charAt(0);
			if(option == 'y' || option=='Y')
				continue;
			else {
				System.out.println("Thank You for Banking with Us!");
				System.exit(0);
			}
		} while(choice!=7);
       scanner.close();
	}
}
