package com.cg.dao;

import com.cg.bean.BankBean;

public interface BankDao {

	public BankBean checkAccount(long accNo);

	public void setData(long accNo, BankBean bean);

}
