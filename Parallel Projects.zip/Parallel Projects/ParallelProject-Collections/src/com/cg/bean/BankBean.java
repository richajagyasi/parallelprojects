package com.cg.bean;

public class BankBean {
	
	private String name;
	private long accountNo;
	private int pin;
	private String phone;
	private int balance;

	String trans = new String();

	public BankBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BankBean(String name, long accountNo, int pin, String phone, int balance) {
		super();
		this.name = name;
		this.accountNo = accountNo;
		this.pin = pin;
		this.phone = phone;
		this.balance = balance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public long setAccountNo(long accountNo) {
		return this.accountNo = accountNo;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public int getBalance() {
		return balance;
	}

	public int setBalance(int balance) {
		return this.balance = balance;
	}

	public String getTrans() {
		return trans;
	}

	public void setTrans(String trans) {
		this.trans = trans;
	}

}
