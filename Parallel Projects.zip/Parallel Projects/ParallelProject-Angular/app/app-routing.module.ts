import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CreateaccountComponent } from './createaccount/createaccount.component';
import { ShowbalanceComponent } from './showbalance/showbalance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { ShowtransactionsComponent } from './showtransactions/showtransactions.component';

const routes: Routes = [
  {
    path: 'app-createaccount',
    component: CreateaccountComponent
  },
  {
    path: 'app-showbalance',
    component: ShowbalanceComponent
  },
  {
    path: 'app-deposit',
    component: DepositComponent 
  },
  {
    path: 'app-withdraw',
    component: WithdrawComponent
  },
  {
    path: 'app-fundtransfer',
    component: FundtransferComponent
  },
  {
    path: 'app-showtransactions',
    component: ShowtransactionsComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
