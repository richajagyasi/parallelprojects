import { Component, OnInit } from '@angular/core';
import { BankService, Bank } from '../bank.service';

@Component({
  selector: 'app-createaccount',
  templateUrl: './createaccount.component.html',
  styleUrls: ['./createaccount.component.css']
})
export class CreateaccountComponent implements OnInit {

  service: BankService;
  bank: Bank;

  constructor(service:BankService) { 
    this.service=service;
  }

  ngOnInit() {
  }

  add(data:any)
  {
    this.bank=new Bank(data.name,data.number,data.balance,data.pin);
    this.service.createAccount(this.bank);
  }

}
