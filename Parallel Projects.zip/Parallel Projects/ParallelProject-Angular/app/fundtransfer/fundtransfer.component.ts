import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-fundtransfer',
  templateUrl: './fundtransfer.component.html',
  styleUrls: ['./fundtransfer.component.css']
})
export class FundtransferComponent implements OnInit {

  service: BankService;

  constructor(service:BankService) { 
    this.service=service;
  }

  transfer(data)
  {
    this.service.transferAmount(data);
  }

  ngOnInit() {
  }

}
