import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-deposit',
  templateUrl: './deposit.component.html',
  styleUrls: ['./deposit.component.css']
})
export class DepositComponent implements OnInit {

  service: BankService;
  
  constructor(service:BankService) {
    this.service=service;
   }

   deposit(data)
   {
     this.service.depositAmount(data);
   }

  ngOnInit() {
  }

}
