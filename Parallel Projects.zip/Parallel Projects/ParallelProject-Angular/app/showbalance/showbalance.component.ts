import { Component, OnInit } from '@angular/core';
import { BankService, Bank} from '../bank.service';

@Component({
  selector: 'app-showbalance',
  templateUrl: './showbalance.component.html',
  styleUrls: ['./showbalance.component.css']
})
export class ShowbalanceComponent implements OnInit {

  service: BankService;
  bank: Bank[];

  constructor(service:BankService) { 
    this.service=service;
  }

  show(data)
  {
    this.bank=this.service.showBalance(data);
  }

  ngOnInit() {
  }

}
