import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { CreateaccountComponent } from './createaccount/createaccount.component';
import { ShowbalanceComponent } from './showbalance/showbalance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { FundtransferComponent } from './fundtransfer/fundtransfer.component';
import { ShowtransactionsComponent } from './showtransactions/showtransactions.component';

@NgModule({
  declarations: [
    AppComponent,
    CreateaccountComponent,
    ShowbalanceComponent,
    DepositComponent,
    WithdrawComponent,
    FundtransferComponent,
    ShowtransactionsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
