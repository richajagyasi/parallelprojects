import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {

  service: BankService;

  constructor(service:BankService) { 
    this.service=service;
  }

  withdraw(data)
  {
    this.service.withdrawAmount(data);
  }

  ngOnInit() {
  }

}
