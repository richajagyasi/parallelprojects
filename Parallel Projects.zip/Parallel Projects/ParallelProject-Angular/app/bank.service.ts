import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class BankService {

  bank: Bank[]=[];
  transaction: Transaction[]=[];

  constructor() { }

  createAccount(b:Bank)
  {
    this.bank.push(b);
  }

  bank1: Bank[];
  showBalance(data):Bank[]
  {
    this.bank1=[];
    for(let b of this.bank)
    {
      if(b.name==data.name && b.pin==data.pin) {
        this.bank1.push(b);
      }
    }
    return this.bank1;
  }

  depositAmount(data)
  {
    for(let i=0;i<this.bank.length;i++)
    {
      if(this.bank[i].name==data.name && this.bank[i].pin==data.pin)
      {
        this.bank[i].balance=this.bank[i].balance+data.dep;
      }
    }
  }

  withdrawAmount(data)
  {
    for(let i=0;i<this.bank.length;i++)
    {
      if(this.bank[i].name==data.name && this.bank[i].pin==data.pin)
      {
        this.bank[i].balance=this.bank[i].balance-data.with;
      }
    }
  }

  transferAmount(data)
  {
    for(let i=0;i<this.bank.length;i++)
    {
      if(this.bank[i].name==data.name && this.bank[i].pin==data.pin) {
        for(let j=0;j<this.bank.length;j++) {
          if(this.bank[j].name==data.to) {
            this.bank[i].balance=this.bank[i].balance-data.tran;
            this.bank[j].balance=this.bank[j].balance+data.tran;
          }
        }
      }
    }
  }

}

export class Bank {
  name: String;
  number: number;
  balance: number;
  pin : number;
  
  constructor(name: string, number:number, balance:number, pin:number) {
    this.name = name;
    this.number = number;
    this.balance = balance;
    this.pin = pin;
  }

}

export class Transaction {
  name: string;
  type: string;
  amount: number;
  to: string;

  constructor(name:string, type:string, amount:number, to:string) {
    this.name=name;
    this.type=type;
    this.amount=amount;
    this.to=to;
  }

}