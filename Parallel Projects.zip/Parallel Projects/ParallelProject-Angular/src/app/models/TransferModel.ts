export interface TransferModel{
    id1:number
    id2:number
    amount:number
}