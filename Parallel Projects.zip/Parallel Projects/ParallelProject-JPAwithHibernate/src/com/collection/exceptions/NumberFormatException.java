package com.collection.exceptions;

public class NumberFormatException extends RuntimeException{
	public NumberFormatException(String message) {
		super(message);
	}
}
