//Collection Service 
package com.collection.server;


import com.collection.exceptions.AccountNotFoundException;
import com.collection.exceptions.InputMismatchException;
import com.collection.exceptions.NumberFormatException;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.collection.beans.TransactionBeans;
import com.collection.beans.UserBeans;
import com.collection.dao.ImplDAO;

public class ImplService implements InterfaceService{
	private ImplDAO cd = new ImplDAO();																	//private object creation for CollectionBeans

	@Override
	public long setBeans(String userName, long userNumber, String userDob, long userAccNo, String userPassword) {
		return cd.setValue(userName, userNumber, userDob, userAccNo, userPassword);
	}

	@Override
	public boolean check(long accNo, String password) {
		return cd.checkAccount(accNo, password);
	}

	@Override
	public double withdraw(double amount, long accNo) {
		return cd.setWithdraw(amount, accNo);
	}

	@Override
	public double deposit(double amount, long accNo) {
		return cd.setDeposit(amount, accNo);
	}

	@Override
	public UserBeans info(long accNo) {
		return cd.showAccount(accNo);
	}

	@Override
	public int transfer(long accNo1, long accNo2, float amount) {
		return cd.setTransfer(accNo1, accNo2, amount);
	}

	@Override
	public String transactions(long accNo) {
		List<TransactionBeans> hm = cd.showTransaction(accNo);

		Iterator i = hm.iterator();
		
		String s = "";
		while(i.hasNext()) {
			
			TransactionBeans t = (TransactionBeans) i.next();
			s = s + t.getTransaction()+"\n";
			
		}
		return s;
	}

	@Override
	public boolean checkName(String userName) {																	//Validation for Name
		char ch[] = new char[userName.length()];
		ch = userName.toCharArray();
		if(userName.equals(null) || ch[0] < 'A' || ch[0] > 'Z') {
			return false;
		}
		return true;
	}

	@Override
	public boolean checkNumber(String userNumber) {
		char ch[] = new char[userNumber.length()];
		ch = userNumber.toCharArray();
		try {
			if((ch[0] >= 'a' && ch[0] <= 'z') || (ch[0] >= 'A' && ch[0] <= 'Z')) {
				throw new InputMismatchException("Enter numbers Only");
			}
			else {
				try {
					if(ch.length<9 || ch.length>10) {
						throw new NumberFormatException("Mobile Number must be 10 digits long.\n\t\tPlease Try Again\n");
					}
				}
				catch(NumberFormatException e) {
					System.out.println(e);
					return false;
				}
				
				return true;
			}
		}
		catch(InputMismatchException ime) {
			System.out.println(ime);
			return false;
		}
	}

	@Override
	public boolean checkDob(String userDob) {																		//Validation for Date Of Birth
		// Returns true if d is in format 
		// /dd/mm/yyyy 
		String regex = "^[0-3]?[0-9]/[0-3]?[0-9]/(?:[0-9]{2})?[0-9]{2}$"; 
		Pattern pattern = Pattern.compile(regex); 
		Matcher matcher = pattern.matcher((CharSequence)userDob); 
		if(matcher.matches()) {
			return true;
		}
		else {
			System.out.println("\t\tDate Of Birth format is dd/mm/yyyy\n\t\tTry Again\n");
			return false;
		}
	}

	@Override
	public boolean checkPassword(String userPassword) {
		if(userPassword.matches("^.*(?=.{8,})(?=..*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).*$")){
			return true;
		}
		System.out.println("\t\tA digit must occur at least once\r\n" + 
				"\t\tA lower case letter must occur at least once\r\n" + 
				"\t\tAn upper case letter must occur at least once\r\n" + 
				"\t\tA special character must occur at least once\r\n" + 
				"\t\tNo whitespace allowed in the entire string\r\n" + 
				"\t\tAt least 8 characters\n\t\t\t\tTry Again\n");
		return false;
	}

	@Override
	public boolean checkAccount(long accNo) {																		//Validation for Account Number
		String tempAccNo = Long.toString(accNo);
		try {	
			if(tempAccNo.length()<9 || tempAccNo.length() > 10) {
				throw new AccountNotFoundException("Account Not Found");
			}
		}
		catch(AccountNotFoundException anf) {
			System.out.println(anf);
			return false;
		}
		return true;
	}


}
