package com.bwa.service;

import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.bwa.bean.Bank;
import com.bwa.bean.Transaction;
import com.bwa.dao.BankDAOImpl;
import com.bwa.dao.IBankDAO;
import com.bwa.exception.BankUserInputException;

public class BankWalletServiceImpl implements IBankWalletService{

	IBankDAO bankDao=new BankDAOImpl();
	
	@Override
	public void addAccount(Bank bank,Transaction tran) {
		bankDao.addUserAccount(bank,tran);
		
	}

	@Override
	public String checkBalance(int accountNo) {
		return  bankDao.getBalance(accountNo);
	}

	@Override
	public String depositMoney(int accountNumber, long amount, Transaction tran) {
		return  bankDao.depositMoney(accountNumber, amount, tran);
	}

	@Override
	public String withdrawMoney(int accountNumber, long amount, Transaction tran) {
		return  bankDao.withdrawMoney(accountNumber, amount, tran);
	}


	@Override
	public String transferMoney(int accountNumber01, long amount01, int accountNumber02,Transaction tran1,Transaction tran2) {
		return bankDao.transferMoney(accountNumber01,amount01,accountNumber02,tran1,tran2);
	}

	@Override
	public String getTransactionDetails(int accountNumber) {

		HashMap<Integer,Transaction> hm=bankDao.printTransactions(accountNumber);
		
		Set set=hm.entrySet();
		Iterator iterator=set.iterator();
		String trans = "" ;
		while(iterator.hasNext())
		{
			Map.Entry pair = (Map.Entry)iterator.next();
			int tid=(int) pair.getKey();
			Transaction transaction=(Transaction) pair.getValue();
			trans=trans+"\n"+"Transaction ID :"+tid+"|| Account number :"+transaction.getAcno()+"|| Transaction Type :"+transaction.getOpertaion();
		}
		return trans;
	}
}
