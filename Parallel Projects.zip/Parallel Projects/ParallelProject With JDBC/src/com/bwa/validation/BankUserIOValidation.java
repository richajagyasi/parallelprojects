package com.bwa.validation;

import com.bwa.dao.BankDAOImpl;
import com.bwa.exception.BankUserInputException;

public class BankUserIOValidation {

	static BankDAOImpl bankDAOImpl=new BankDAOImpl();
	
	public static boolean checkName(String name) throws BankUserInputException {
		int n = name.length();
		char[] ch = name.toCharArray();
		for (int i = 0; i < n; i++) {
			try {
				if (ch[i] > 64 && ch[i] < 122 && ch[0] > 63 && ch[0] < 90) {
					return true;
				} else {
					throw new BankUserInputException("Invalid Name");
				}
			} catch (BankUserInputException E) {
				System.out.println(E);
				return false;
			}
		}
		return false;
	}

	public static boolean checkPIN(int pin) throws BankUserInputException {
		try {
			String g=Integer.toString(pin);
			if (g.matches("[0-9]+") && g.length() == 4) {
				return true;
			} else {
				throw new BankUserInputException("Invalid PIN");

			}
		} catch (BankUserInputException e) {
			return false;
		}
	}

	public static boolean checkPhoneNumber(String number) throws BankUserInputException {
		try {
			if (number.matches("[0-9]+") && number.length() == 10) {
				return true;
			} else {
				throw new BankUserInputException("Invalid Phonenumber");
			}
		} catch (BankUserInputException e) {
			return false;
		}
	}
	
	public static boolean checkAccNo(int accountNumber)
	{
		if(bankDAOImpl.checkAccountNumber(accountNumber))
		return true;
		
		System.out.println("INVALID ACCOUNT NUMBER");
		return false;
		
     }
}