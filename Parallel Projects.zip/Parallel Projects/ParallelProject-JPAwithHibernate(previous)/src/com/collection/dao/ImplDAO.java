//Collection DAO
package com.collection.dao;

import java.time.LocalDateTime;
import java.util.*;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.collection.beans.TransactionBeans;
import com.collection.beans.UserBeans;

public class ImplDAO implements InterfaceDAO{
	TransactionBeans tb;
	ConnectionDAO cd = new ConnectionDAO();
	EntityManager con;
	UserBeans cb = new UserBeans(), cb1 = new UserBeans();
	static int i = 0;

	@Override
	public long setValue(String userName, long userNumber, String userDob, long userAccNo, String userPassword) {			//Creating new User
		con = cd.getConnection();
		con.getTransaction().begin();	
		
		cb = new UserBeans();
		cb.setUserBalance(25000.00);
		cb.setUserDob(userDob);
		cb.setUserName(userName);
		cb.setUserNumber(userNumber);
		cb.setUserPassword(userPassword);
		cb.setUserAccNo(userAccNo);
		
		con.persist(cb);
		con.getTransaction().commit();
		
		con = cd.getConnection();
		con.getTransaction().begin();	
		
		tb = new TransactionBeans();
		String str = "Account No " + userAccNo + " is Created.";
		tb.setTransaction(str);
		tb.setUb(cb);
		
		con.persist(tb);
		
		
		con.getTransaction().commit();
		return userAccNo;
	}

	@Override
	public boolean checkAccount(long accNo, String password) {																//Check account number and password
		con = cd.getConnection();
		con.getTransaction().begin();
		cb = con.find(UserBeans.class, new Long(accNo));
		con.getTransaction().commit();
		if(cb.getUserAccNo()==accNo && password.equals(cb.getUserPassword())) {
			return true;
		}
		return false;
	}

	@Override
	public double setWithdraw(double amount, long accNo) {																	//Withdraw method
		con = cd.getConnection();
		con.getTransaction().begin();
		cb = con.find(UserBeans.class, new Long(accNo));
		tb = new TransactionBeans();
		Double tempAmount = cb.getUserBalance();
		cb.setUserBalance(tempAmount-amount);
		String tempTrans = "Amount Rs."+ amount + " withdrawn from Account No " + accNo + "." ;
		tb.setTransaction(tempTrans);
		tb.setUb(cb);
		con.persist(tb);
		con.getTransaction().commit();

		return amount;
	}

	@Override
	public double setDeposit(double amount, long accNo) {																	//Deposit method
		con = cd.getConnection();
		con.getTransaction().begin();
		cb = con.find(UserBeans.class, new Long(accNo));
		tb = new TransactionBeans();
		Double tempAmount = cb.getUserBalance();
		cb.setUserBalance(tempAmount+amount);
		String tempTrans = "Amount Rs."+ amount + " deposited to Account No " + accNo + "." ;
		tb.setTransaction(tempTrans);
		tb.setUb(cb);
		con.persist(tb);
		con.getTransaction().commit();

		return amount;
	}

	@Override
	public UserBeans showAccount(long accNo) {																				//User Information method
		con = cd.getConnection();
		con.getTransaction().begin();
		cb = con.find(UserBeans.class, new Long(accNo));
		
		con.getTransaction().commit();

		return cb;
	}

	@Override
	public int setTransfer(long accNo1, long accNo2, float amount) {													//Transfer amount from one account to another method
		con = cd.getConnection();
		con.getTransaction().begin();
		cb = con.find(UserBeans.class, new Long(accNo1));
		tb = new TransactionBeans();
		cb1 = con.find(UserBeans.class, new Long(accNo2));
		
		Double tempAmount = cb.getUserBalance();
		Double tempAmount1 = cb1.getUserBalance();
		cb.setUserBalance(tempAmount-amount);
		cb1.setUserBalance(tempAmount1+amount);
		String tempTrans = "Amount Rs."+ amount + " transfered from Account No. "+ accNo1 + " to Account No " + accNo2 + "." ;
		tb.setTransaction(tempTrans);
		tb.setUb(cb);
		con.persist(tb);
		con.getTransaction().commit();
		
		con = cd.getConnection();
		con.getTransaction().begin();
		tb = new TransactionBeans();
		tb.setTransaction(tempTrans);
		tb.setUb(cb1);
		con.persist(tb);
		con.getTransaction().commit();
		return 1;
	}

	@Override
	public List<TransactionBeans> showTransaction(long accNo) {																				//Show Transaction method
		
		con = cd.getConnection();
		con.getTransaction().begin();
//		tb = new TransactionBeans();
//		tb = con.find(TransactionBeans.class, new Long(accNo));
		
		TypedQuery<TransactionBeans> query = (TypedQuery<TransactionBeans>) con.createQuery("SELECT t FROM TransactionBeans t WHERE AccountNo=?1").setParameter(1, accNo); 
		List<TransactionBeans> list = query.getResultList();
//		System.out.println(list);
		con.getTransaction().commit();

		return list;
	}

}
