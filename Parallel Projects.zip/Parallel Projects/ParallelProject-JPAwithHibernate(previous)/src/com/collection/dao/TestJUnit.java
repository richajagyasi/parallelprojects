package com.collection.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;



class TestJUnit {
	ImplDAO cd1 = new ImplDAO();	
	double tAmount = 25000.00;
	
	@Test
	public void withdraw() {
		double expected = tAmount;
		double observed = cd1.setWithdraw(25000, 1118601579);
		System.out.println("observed : " + observed);
		assertEquals(expected, observed);
	}
	
	@Test
	public void check() {
		boolean expected = true;
		boolean observed = cd1.checkAccount(1118601579, "Hello123#");
		assertEquals(expected, observed);
	}
	
	@Test
	public void deposit() {
		double expected = 10000;
		double observed = cd1.setDeposit(10000, 1118601579);
		assertEquals(expected, observed);
	}
	
	@Test
	public void transfer() {
		double expected = 1;
		int actual = cd1.setTransfer(1118601579, 1046309105, 200);
		assertEquals(expected, actual);
	}
}
