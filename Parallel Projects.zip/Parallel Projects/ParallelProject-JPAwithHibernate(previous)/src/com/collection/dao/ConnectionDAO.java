package com.collection.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class ConnectionDAO {
	public EntityManager getConnection() {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Connect");
	
		EntityManager em=emf.createEntityManager();
		return em;
	}
}
