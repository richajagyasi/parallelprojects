package com.cg.parallelprojectspringrest;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class ParallelprojectSpringrestApplicationTests {

	@Test
	public void contextLoads() {
	}

}
