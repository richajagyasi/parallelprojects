package com.cg.parallelprojectspringrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.parallelprojectspringrest.bean.User;
import com.cg.parallelprojectspringrest.service.BankService;

@RestController
public class BankController {

	@Autowired
	BankService bankService;
	
	@RequestMapping(value="/create", method=RequestMethod.POST)
	public List<User> createAccount(User customer)
	{
		return bankService.createAccount(customer);
	}
	
}
