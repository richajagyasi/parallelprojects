package com.cg.parallelprojectspringrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.parallelprojectspringrest.bean.User;
import com.cg.parallelprojectspringrest.dao.BankDao;

@Service
public class BankServiceimpl implements BankService {

	@Autowired
	BankDao bankDao;
	
	@Override
	public List<User> createAccount(User customer) {
		bankDao.save(customer);
		return bankDao.findAll();
	}

}
