package com.cg.parallelprojectspringrest.service;

import java.util.List;

import com.cg.parallelprojectspringrest.bean.User;

public interface BankService {

	public List<User> createAccount(User customer);
	
}
