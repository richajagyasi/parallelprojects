package com.cg.parallelprojectspringrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ParallelprojectSpringrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ParallelprojectSpringrestApplication.class, args);
	}

}
