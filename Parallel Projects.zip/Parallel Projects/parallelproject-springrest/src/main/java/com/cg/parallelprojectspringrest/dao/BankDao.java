package com.cg.parallelprojectspringrest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.parallelprojectspringrest.bean.User;

@Repository
public interface BankDao extends JpaRepository<User, Integer> {

}
