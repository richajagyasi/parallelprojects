import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-withdraw',
  templateUrl: './withdraw.component.html',
  styleUrls: ['./withdraw.component.css']
})
export class WithdrawComponent implements OnInit {
  amt: number;
  constructor(private router: Router, private userService: BankServiceService) { }

  ngOnInit() {
  }
  withdraw(amount) {

    this.userService.withdraw(amount).subscribe(data => {

      this.amt = data;

    });

  }
}
