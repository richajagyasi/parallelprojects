import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
str:string;
  constructor(private router: Router, private userService: BankServiceService) { }

  ngOnInit() {
  }
  fundTransfer(destination: any,amount: any)
  {  
this.userService.fundTransfer(destination,amount).subscribe(data => {
this.str = data;
      });
console.log(this.str);
  }
}
