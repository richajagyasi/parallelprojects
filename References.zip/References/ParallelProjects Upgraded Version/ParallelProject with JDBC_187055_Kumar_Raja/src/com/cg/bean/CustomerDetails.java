package com.cg.bean;

public class CustomerDetails {
	
	private String firstname;
	private String lastname;
	private long phonenum;
	private long aadharnum;
	private long accountnum;
	private double money;
	private long AccountNumber;
	
	public CustomerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CustomerDetails(String fname, String lname, long phnum, long aadharnum, long accountnum, double money) {
		super();
		this.firstname = fname;
		this.lastname = lname;
		this.phonenum = phnum;
		this.aadharnum = aadharnum;
		this.accountnum = accountnum;
		this.money = money;
	}

	public String getFname() {
		return firstname;
	}
	public void setFname(String fname) {
		this.firstname = fname;
	}

	public String getLname() {
		return lastname;
	}
	public void setLname(String lname) {
		this.lastname = lname;
	}

	public long getPhnum() {
		return phonenum;
	}
	public void setPhnum(long phnum) {
		this.phonenum = phnum;
	}

	public long getAadharnum() {
		return aadharnum;
	}
	public void setAadharnum(long aadharnum) {
		this.aadharnum = aadharnum;
	}

	public void setAccountnum(long accountnum) {
		this.accountnum = accountnum;
	}
	
	public long setAcountnum()
	{
		long accno=(long) ((Math.random() * ((9999999 - 999) + 1)) + 999); 
		AccountNumber = accno;
		return accno;
	}
	public long getAccountnum() {
		return AccountNumber;
	}
	public double getMoney() {
		return money;
	}
	public void setMoney(double money) {
		this.money = money;
	}

	@Override
	public String toString() {
		return "Customer [fname=" + firstname + ", lname=" + lastname + ", phnum=" + phonenum + ", aadharnum=" + aadharnum
				+ ", accountnum=" + accountnum + ", money=" + money + "]";
	}
}
