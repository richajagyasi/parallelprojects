package com.cg.service;

import java.util.Scanner;

import com.cg.bean.CustomerDetails;
import com.cg.dao.BankDao;
import com.cg.validation.BankValidation;


public class BankService {
	private static BankDao dao = new BankDao();
    private static BankValidation val=new BankValidation();
	private static Scanner sc = new Scanner(System.in);


	public CustomerDetails saveCustomerInfo() {

		CustomerDetails c = new CustomerDetails();
		System.out.println("Enter First Name:");
		String str = sc.next();
		c.setFname(str);
		System.out.println("Enter Last Name:");
		String str1 = sc.next();
		c.setLname(str1);
		System.out.println("Enter Phone Number:");
		long l1 = sc.nextLong();
		if(val.phnnum(l1))
			c.setPhnum(l1);
		else {
			System.out.println("Please enter valid 10 digit Phone Number");
			System.exit(0);
		}
		System.out.println("Enter Aadhar Number:");
		long l2 = sc.nextLong();
		if(val.aadnum(l2))
			c.setAadharnum(l2);
		else {
			System.out.println("Please enter valid 12 digit Aadhar Number");
			System.exit(0);
		}
		System.out.println("Enter money to be deposited");
		c.setMoney(sc.nextDouble());
		return dao.save(c);	
		
	}
	
	
	public String showBalance(long accnum) {
		
		return dao.showBal(accnum);
	}


	
	public void depositAmount(long acnum, double money1) {
		
		dao.deposit(acnum, money1);
	}


	public void withdrawAmount(long acnum1, double money) {
		
			System.out.println("Enter amount to be withdrawn:");
			dao.withdraw(acnum1, money);
		
	}


	public double fundTransfer(long yaccnum, long raccnum, long amt) {
		
			return dao.transfer(yaccnum, raccnum, amt);
		
	}


	public String printTransactions(long accountnumber) {
		// TODO Auto-generated method stub
		return null;
	}


}
