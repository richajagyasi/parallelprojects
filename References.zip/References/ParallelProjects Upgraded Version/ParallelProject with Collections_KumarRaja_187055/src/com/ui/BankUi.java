package com.ui;
import java.util.Scanner;
public class BankUi {
public static void main(String args[]) {

		int i;
        char option;
        BankModules b1 = new BankModules();
        Scanner s = new Scanner(System.in);
        do {
            System.out.println(" 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Print Transactions \n 7. Exit\n*********************");
            System.out.print("Enter your choice : ");
            i = s.nextInt();
            switch(i) {
             case 1:
            	 b1.accountCreation();
                 break;
             case 2:
            	 b1.balanceCheck();
                 break;
             case 3:
            	 b1.deposit();
                 break;
             case 4:
            	 b1.withdraw();
            	 break;
             case 5:
            	 b1.fundTransfer();
            	 break;
             case 6:
            	 b1.printTransactions();
            	 break;
             case 7:
                 System.exit(0);

			}
            System.out.print("wanna continue???? (y/n)...? : ");
            option = s.next().charAt(0);
            if(option =='y' || option =='Y')
            	continue;
            else {
            	System.out.println("Thank You ! Use our services next time....");
            	System.exit(0);
            	}
            } while(i != 7 );
        s.close();
}
}